package io.bootify.appy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppyApplication {

    public static void main(final String[] args) {
        SpringApplication.run(AppyApplication.class, args);
    }

}
