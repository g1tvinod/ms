package io.bootify.appy.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EntityScan("io.bootify.appy.domain")
@EnableJpaRepositories("io.bootify.appy.repos")
@EnableTransactionManagement
public class DomainConfig {
}
