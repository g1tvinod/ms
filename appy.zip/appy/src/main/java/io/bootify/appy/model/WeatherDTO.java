package io.bootify.appy.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class WeatherDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String city;

    @NotNull
    private Integer temp;

    public Long getId() {
        return id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(final String city) {
        this.city = city;
    }

    public Integer getTemp() {
        return temp;
    }

    public void setTemp(final Integer temp) {
        this.temp = temp;
    }

}
