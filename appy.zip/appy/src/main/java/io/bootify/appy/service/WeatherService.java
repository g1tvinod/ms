package io.bootify.appy.service;

import io.bootify.appy.domain.Weather;
import io.bootify.appy.model.WeatherDTO;
import io.bootify.appy.repos.WeatherRepository;
import io.bootify.appy.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class WeatherService {

    private final WeatherRepository weatherRepository;

    public WeatherService(final WeatherRepository weatherRepository) {
        this.weatherRepository = weatherRepository;
    }

    public List<WeatherDTO> findAll() {
        final List<Weather> weathers = weatherRepository.findAll(Sort.by("id"));
        return weathers.stream()
                .map(weather -> mapToDTO(weather, new WeatherDTO()))
                .toList();
    }

    public WeatherDTO get(final Long id) {
        return weatherRepository.findById(id)
                .map(weather -> mapToDTO(weather, new WeatherDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final WeatherDTO weatherDTO) {
        final Weather weather = new Weather();
        mapToEntity(weatherDTO, weather);
        return weatherRepository.save(weather).getId();
    }

    public void update(final Long id, final WeatherDTO weatherDTO) {
        final Weather weather = weatherRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(weatherDTO, weather);
        weatherRepository.save(weather);
    }

    public void delete(final Long id) {
        weatherRepository.deleteById(id);
    }

    private WeatherDTO mapToDTO(final Weather weather, final WeatherDTO weatherDTO) {
        weatherDTO.setId(weather.getId());
        weatherDTO.setCity(weather.getCity());
        weatherDTO.setTemp(weather.getTemp());
        return weatherDTO;
    }

    private Weather mapToEntity(final WeatherDTO weatherDTO, final Weather weather) {
        weather.setCity(weatherDTO.getCity());
        weather.setTemp(weatherDTO.getTemp());
        return weather;
    }

}
